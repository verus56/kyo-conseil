import Typewriter from 'typewriter-effect/dist/core';

class Conversation {

    static apiKey = "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";
    static apiEndpoint = "https://api.openai.com/v1/chat/completions";
    static model = 'gpt-3.5-turbo';

    constructor( emailContents = '', token = false ) {

        this.emailContents = trimAndRegulate( emailContents );
        this.messages = [];

        if( token ) {
            this.token = token;
        } else {
            this.token = false;
        }


    }

    static hasSavedData( token = false ) {

        let previousData = false;

        if( token ) {
            previousData = localStorage.getItem( token );
        }

        if( !previousData ) {
            return false;
        } else {
            return previousData;
        }

    }

    getSavedData( property ) {

        if( !this.token ) { return false; }

        let previousData = localStorage.getItem( this.token );

        if( !previousData ) { return false }

        previousData = JSON.parse( previousData );

        if( !previousData.hasOwnProperty( property ) ) { return false; }
        
        return previousData[ property ];

    }

    saveToLocalStorage( property, value ) {

        if( !this.token ) { return false; }

        let previousData = localStorage.getItem( this.token );

        if( previousData ) {

            previousData = JSON.parse( previousData );

        } else {

            previousData = {};

        }

        if( previousData.hasOwnProperty( property ) && Array.isArray( previousData[ property ] ) ) {

            previousData[ property ].push( value );

        } else {

            previousData[ property ] = value;

        }

        let newData = JSON.stringify( previousData );

        localStorage.setItem( this.token, newData );

    }

    async getResponse( action = "summary", content = `here's an email I recieved, provide me with a shorter version in original language : "${this.emailContents}"`, role= 'user' ) {        


            let savedData = this.getSavedData( action );


            if( this.token && savedData ) {

                return new Promise( (resolve, reject) => {

                    resolve( savedData );

                });


            }

            const data = {
                "model": Conversation.model,
                messages: [
                    { role, content }
                ]
            
            };

            return fetch( Conversation.apiEndpoint, {

                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${ Conversation.apiKey}`,
                },
                
                "body": JSON.stringify( data ),
            
            })
            
            .then( ( response ) => {
    
                const { 
                    ok = false,
                    statusText = '',
                
                } = response;
    
                if( !ok ) {
    
                    throw Error( statusText );
    
                }
    
                return response;
    
            })
    
            .then( ( response ) => response.json() )
            
            .then( ( response ) => {
                
                
                const { 
                    choices = []
                } = response;
    
                if( choices.length == 0 ) {
    
                    throw Error( `Chat gpt Couldn't handle this` );
    
                }
                
                choices.forEach( choice => {
    
                    const { message } = choice;
                    this.messages.push( message );
                    
                });
    
                const [ { message: reply } ] = choices;
                
                this.saveToLocalStorage( action, reply );
    
                return reply;
        
                
            });
        
    }

    async generateAutoReply( query = false ) {

        if( !query ) { return; }

        let params = new URLSearchParams( query );

        let replyTone = params.get( "reply-tone" );

        let content = `Reply To this Email`; 

        if( replyTone ) {

            content = `${content} with ${ replyTone } tone`;

        }

        let richness = params.get( "richness" );

        if( richness ) {

            content = `${content} and with ${ richness }`;

        }

        let suggestion = params.get( "suggestion" );

        if( suggestion ) {

            content = `${content}, ${suggestion}`

        }

        content = `${ content } : "${this.emailContents}"`

        return this.getResponse( query, content );
        
    }

}


/**
 * Convert a template string into HTML DOM nodes
 * @param  {String} str The template string
 * @return {Node}       The template HTML
 */
const stringToHTML =  (str) => {

    let support = (function () {
        if (!window.DOMParser) return false;
        var parser = new DOMParser();
        try {
            parser.parseFromString('x', 'text/html');
        } catch(err) {
            return false;
        }
        return true;
    })();


	// If DOMParser is supported, use it
	if (support) {
		var parser = new DOMParser();
		var doc = parser.parseFromString(str, 'text/html');
		return doc.body;
	}

	// Otherwise, fallback to old-school method
	var dom = document.createElement('div');
	dom.innerHTML = str;
	return dom;

};

const loadingIcon = `<svg width="24px" height="12px" class="loading-icon">

<rect class="line"></rect>
<rect class="line"></rect>
<rect class="line"></rect>

</svg> `;


const trimAndRegulate = ( text = '' ) => {

    return text.replace( /\n(\s)*/gm, "\n" );

}

const summaryMessageElements = ( extraClasses = '' ) => {

    let summary = stringToHTML(`
    
        <div class="kyo-summary kyo-summary--loading ${extraClasses}">

            <span class="kyo-summary__title">Summarized Version</span>

            <p class="kyo-summary__content js-summary-content" ></p>

            ${loadingIcon}

            <a href="#" onClick=''>Generate an auto reply</a>

        </div>
    
    `);

    summary.querySelector( "a" ).addEventListener( "click", ( event ) => { 

        event.preventDefault();
        document.querySelector( '.ams' )?.click()
    
    });

    return summary;

}

const autoReplyForm = ( token = false, callback = () => {} ) => {

    let formHtml = stringToHTML( `

    <div class="autoreply__container">
    
    
        <form id="auto-reply" class="autoreply">

            <h3 class="autoreply__title">Generate Auto Reply</h3>

            <input type='hidden' value="reply" />
            
            <fieldset>

                <legend>Tone</legend>

                <div class='autoreply__radio'>

                    <input id="reply-tone-professional" name="reply-tone" value="professional" type='radio' />
                    
                    <label for="reply-tone-professional">professional</label>
                
                </div>

                <div class='autoreply__radio'>

                    <input id="reply-tone-friendly" name="reply-tone" value="friendly" type='radio' />
                    <label for="reply-tone-friendly">friendly</label>
                
                </div>


                <div class='autoreply__radio'>

                    <input id="reply-tone-serious" name="reply-tone" value="serious" type='radio' />
                    <label for="reply-tone-serious">serious</label>
                
                </div>

                <div class='autoreply__radio'>

                    <input id="reply-tone-grateful" name="reply-tone" value="grateful" type='radio' />
                    <label for="reply-tone-grateful">grateful</label>
                
                </div>

                <div class='autoreply__radio'>

                    <input id="reply-tone-agressive" name="reply-tone" value="less friendly" type='radio' />
                    <label for="reply-tone-agressive">less friendly</label>
                
                </div>


            </fieldset>
            

             
            <fieldset>

                <legend>Richness</legend>

                <div class='autoreply__radio'>

                    <input id="richness-detailed" value="more details" name="richness" type='radio' />
                    
                    <label for="richness-detailed">More Details</label>
                
                </div>


                <div class='autoreply__radio'>

                    <input id="richness-less-detailed" value="less details" name="richness" type='radio' />
                    <label for="richness-less-detailed">Shorter</label>
                
                </div>


            </fieldset>

            <fieldset>

                <legend>Custom edits</legend>

                <textarea name="suggestion" class="autoreply__suggestion" placeholder="Write Your Own Customization"></textarea>

            </fieldset>

            <button class="autoreply__submit" type="submit">
            
                <span> Generate Reply </span>

                ${loadingIcon}

            </button>

        </form>
        
    </div>
    
    `);

    formHtml.querySelectorAll( ".autoreply__radio label" ).forEach( ( item ) =>  {

        item.addEventListener( 'click', (event) => {

            let input = event?.target?.parentNode?.querySelector( "input" ); 
            
            if( input?.checked ) {
                event.preventDefault();
                input.checked = false;
            }

        });

    });


    let form = formHtml.querySelector( "#auto-reply" );

    form.addEventListener( "submit", (event) => {

        form.classList.add( "autoreply--loading" );

        event.preventDefault();

        let query = new URLSearchParams(new FormData( event.target )).toString();

        const emailCore = document.querySelector( ".ii.gt" );

        const emailContents  =  emailCore.textContent;


        let conversation = new Conversation( emailContents, token );

        conversation.generateAutoReply( query ).then( (reply) => {

            form.classList.remove( "autoreply--loading" );

            return reply;

        }).then( callback );

    });


    return formHtml;

}


function emailObserver() {


    const config = { attributes: false, childList: true, subtree: true };

    // const toolbox = document.querySelector( '.ams.bkH' );

    const insideAnEmailUrlHashRegex = /^#([a-z]{1,10}\/)+(?=[BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz]{32,})/;

    const insideAnEmail = insideAnEmailUrlHashRegex.test( window.location.hash );

    if( !insideAnEmail ) { return false; }

    const observer = new MutationObserver(( mutationList, observer ) => {

        const emailCore = document.querySelector( ".ii.gt" );

        if( !emailCore ) { return false; }

        // disconnect the observer

        observer.disconnect();

        const [ token ] = window.location.hash.match( /(?<=\/)([BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz]{32,})/ );

        const emailContents  =  emailCore.textContent;

        const conversation = new Conversation( emailContents, token );

        const summaryElement = summaryMessageElements();

        emailCore.prepend( summaryElement );
  
        conversation.getResponse( "summary" ).then(({ content = "" } ) => {

            let typer = new Typewriter( summaryElement.querySelector( ".js-summary-content" ), {
                loop: false,
                delay: 5,
            });

            summaryElement.querySelector( ".kyo-summary--loading" ).classList.remove( 'kyo-summary--loading' );
            
            typer.typeString( content ).start();

        });


    });

    observer.observe(document, config);
        
    const replyFormObserver = new MutationObserver( (mutationList , observer) => {

        const [ token ] = window.location.hash.match( /(?<=\/)([BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz]{32,})/ );

        let gmailReplyForm = document.querySelector(".M9");

        if( !gmailReplyForm ) { return; }

        observer.disconnect();

        console.log( "found it" );

        gmailReplyForm.prepend( autoReplyForm( token, ( reply ) => {

            gmailReplyForm.querySelector( ".Am" ).textContent = reply.content;

        } ) );



    });

    replyFormObserver.observe( document, config );
    
    
}

addEventListener('popstate', emailObserver);

addEventListener( 'DOMContentLoaded', emailObserver );

emailObserver();




